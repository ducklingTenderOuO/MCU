/*
 * SPI.c
 *
 * Created: 29/04/2026
 *  Author: astri
 */ 

#include "SPI.h"

void SPI_MasterInit(void)
{
	/* Set SS (PB2), MOSI (PB3) and SCK (PB5) as Output */
	DDRB |= (1<<PINB2)|(1<<PINB3)|(1<<PINB5);
	/* Set MISO (PB4) as Input */
	DDRB &= ~(1<<PINB4);
	/* SS HIGH (inactive) initially */
	PORTB |= (1<<PINB2);
	SPCR = (1<<SPE)|(1<<MSTR);
	/* Double speed: fck/2 = 8 MHz */
	SPSR = (1<<SPI2X);
}

void SPI_MasterTransmit(char cData)
{
	/* Start transmission */
	SPDR = cData;
	/* Wait for transmission complete */
	while(!(SPSR & (1<<SPIF)));
}