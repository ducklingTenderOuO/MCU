/*
 * main.c
 *
 * Created: 4/29/2026 11:06:52 AM
 *  Author: astri
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <math.h>
#include "SPI.h"
 
#define N_SAMPLES   100          
#define DAC_MAX     4095U        
#define DAC_MID     2048U        
 
static uint16_t sine_table[N_SAMPLES];
 
volatile uint8_t  sample_index  = 0;   
volatile uint8_t  do_output     = 0;   
static   uint8_t  wave_mode     = 0;   
 
static inline void DAC_Output(uint16_t value)
{
	if (value > DAC_MAX) value = DAC_MAX;
 
	uint8_t high = 0x30 | ((uint8_t)(value >> 8) & 0x0F);
	uint8_t low  = (uint8_t)(value & 0xFF);
 
	PORTB &= ~(1 << PINB2);   /* CS = LOW  */
	SPI_MasterTransmit((char)high);
	SPI_MasterTransmit((char)low);
	PORTB |= (1 << PINB2);    /* CS = HIGH */
}
 
static uint16_t get_sample(uint8_t index)
{
	switch (wave_mode)
	{
		case 0:
			return (uint16_t)((uint32_t)index * DAC_MAX / (N_SAMPLES - 1));
 
		case 1:
			return (index < N_SAMPLES / 2) ? DAC_MAX : 0;
 
		case 2:
		{
			uint8_t half = N_SAMPLES / 2;
			if (index < half)
				return (uint16_t)((uint32_t)index * DAC_MAX / (half - 1));
			else
				return (uint16_t)((uint32_t)(N_SAMPLES - 1 - index) * DAC_MAX / (half - 1));
		}
 
		case 3:
		default:
			return sine_table[index];
	}
}
 
static void build_sine_table(void)
{
	for (uint8_t i = 0; i < N_SAMPLES; i++)
	{
		double angle = 2.0 * M_PI * i / N_SAMPLES;
		sine_table[i] = (uint16_t)((sin(angle) + 1.0) * (DAC_MAX / 2.0) + 0.5);
		if (sine_table[i] > DAC_MAX) sine_table[i] = DAC_MAX;
	}
}

static uint8_t read_wave_select(void)
{
	uint8_t s0 = !(PIND & (1 << PIND0));   /* SW1 en PD0 */
	uint8_t s1 = !(PIND & (1 << PIND1));   /* SW2 en PD1 */
	return (s1 << 1) | s0;
}
 
static void Timer0_Init(void)
{
	TCCR0A = (1 << WGM01);          /* CTC mode                    */
	TCCR0B = (1 << CS01);            /* prescaler = 8               */
	OCR0A  = 199;                    /* 100 us a 16 MHz / 8         */
	TIMSK0 = (1 << OCIE0A);          /* habilita interrupcion CTC   */
}
 
ISR(TIMER0_COMPA_vect)
{
	do_output = 1;
}
 
int main(void)
{
	DDRD  &= ~((1 << PIND0) | (1 << PIND1));
	PORTD |=  ((1 << PIND0) | (1 << PIND1));
 
	build_sine_table();
 
	SPI_MasterInit();
 
	Timer0_Init();
 
	sei();
 
	while (1)
	{
		if (do_output)
		{
			do_output = 0;
 
			wave_mode = read_wave_select();
 
			DAC_Output(get_sample(sample_index));
 
			sample_index++;
			if (sample_index >= N_SAMPLES)
				sample_index = 0;
		}
	}
}