
/*
 * SPI.h
 *
 * Created: 29/04/2026 11:08:13 a. m.
 *  Author: astri
 */ 

#ifndef SPI_H_
#define SPI_H_

#include <avr/io.h>

void SPI_MasterInit(void);
void SPI_MasterTransmit(char cData);

#endif /* SPI_H_ */