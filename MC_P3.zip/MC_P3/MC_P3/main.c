/*
 * MC_P3.c
 *
 * Created: 26/02/2026 12:29:01 p. m.
 * Author : astri
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>

void prender_columna(void);   
void prender_fila(void);
void prender_todos(void);
void mostrar_letra(uint8_t letra[], uint8_t *modo);
void mostrar_mensaje(uint8_t *modo);
void escribir_columna(uint8_t dato);

uint8_t estado = 0;

uint8_t A[8] = {
	0b00111100,
	0b01000010,
	0b10000001,
	0b10000001,
	0b11111111,
	0b10000001,
	0b10000001,
	0b10000001
};
uint8_t B[8] = {
	0b00111100,
	0b01000010,
	0b10000001,
	0b10000001,
	0b01111111,
	0b10000001,
	0b01000001,
	0b00111111
};
uint8_t C[8] = {
	0b11111111,
	0b00000001,
	0b00000001,
	0b00000001,
	0b00000001,
	0b00000001,
	0b00000001,
	0b11111111
};
uint8_t D[8] = {
	0b00111111,
	0b01000001,
	0b10000001,
	0b10000001,
	0b10000001,
	0b10000001,
	0b10000001,
	0b01111111
};
uint8_t E[8] = {
	0b11111111,
	0b00000001,
	0b00000001,
	0b00000001,
	0b11111111,
	0b00000001,
	0b00000001,
	0b11111111
};
uint8_t F[8] = {
	0b11111111,
	0b00000001,
	0b00000001,
	0b00000001,
	0b00111111,
	0b00000001,
	0b00000001,
	0b00000001
};
uint8_t G[8] = {
	0b11111111,
	0b00000001,
	0b00000001,
	0b00000001,
	0b11111001,
	0b10000001,
	0b10000001,
	0b11111111
};
uint8_t H[8] = {
	0b10000001,
	0b10000001,
	0b10000001,
	0b11111111,
	0b10000001,
	0b10000001,
	0b10000001,
	0b10000001
};
uint8_t I[8] = {
	0b01111110,
	0b00011000,
	0b00011000,
	0b00011000,
	0b00011000,
	0b00011000,
	0b00011000,
	0b01111110
};
uint8_t J[8] = {
	0b11111000,
	0b00100000,
	0b00100000,
	0b00100000,
	0b00100000,
	0b00100001,
	0b00100001,
	0b00011110
};
uint8_t K[8] = {
	0b01000001,
	0b00100001,
	0b00010001,
	0b00001111,
	0b00010001,
	0b00100001,
	0b01000001,
	0b10000001
};
uint8_t L[8] = {
	0b00000001,
	0b00000001,
	0b00000001,
	0b00000001,
	0b00000001,
	0b00000001,
	0b00000001,
	0b11111111
};
uint8_t M[8] = {
	0b10000001,
	0b11000011,
	0b10100101,
	0b10011001,
	0b10000001,
	0b10000001,
	0b10000001,
	0b10000001
};
uint8_t N[8] = {
	0b10000001,
	0b10000011,
	0b10000101,
	0b10001001,
	0b10010001,
	0b10100001,
	0b11000001,
	0b10000001
};
uint8_t O[8] = {
	0b00111100,
	0b01000010,
	0b10000001,
	0b10000001,
	0b10000001,
	0b10000001,
	0b01000010,
	0b00111100
};
uint8_t P[8] = {
	0b00111111,
	0b01000001,
	0b01000001,
	0b00111111,
	0b00000001,
	0b00000001,
	0b00000001,
	0b00000001
};
uint8_t Q[8] = {
	0b00111100,
	0b01000010,
	0b10000001,
	0b10000001,
	0b10010001,
	0b10100001,
	0b01000010,
	0b10111100
};
uint8_t R[8] = {
	0b00111111,
	0b01000001,
	0b01000001,
	0b00111111,
	0b00010001,
	0b00100001,
	0b01000001,
	0b10000001
};
uint8_t S[8] = {
	0b01111110,
	0b10000001,
	0b00000001,
	0b00111110,
	0b01000000,
	0b10000000,
	0b10000001,
	0b01111110
};
uint8_t T[8] = {
	0b11111111,
	0b00011000,
	0b00011000,
	0b00011000,
	0b00011000,
	0b00011000,
	0b00011000,
	0b00011000
};
uint8_t U[8] = {
	0b10000001,
	0b10000001,
	0b10000001,
	0b10000001,
	0b10000001,
	0b10000001,
	0b01000010,
	0b00111100
};
uint8_t V[8] = {
	0b10000001,
	0b10000001,
	0b10000001,
	0b10000001,
	0b01000010,
	0b01000010,
	0b00100100,
	0b00011000
};
uint8_t W[8] = {
	0b10000001,
	0b10000001,
	0b10000001,
	0b10011001,
	0b10011001,
	0b10100101,
	0b11000011,
	0b10000001
};
uint8_t X[8] = {
	0b10000001,
	0b01000010,
	0b00100100,
	0b00011000,
	0b00011000,
	0b00100100,
	0b01000010,
	0b10000001
};
uint8_t Y[8] = {
	0b10000001,
	0b01000010,
	0b00100100,
	0b00011000,
	0b00011000,
	0b00011000,
	0b00011000,
	0b00011000
};
uint8_t Z[8] = {
	0b11111111,
	0b01000000,
	0b00100000,
	0b00010000,
	0b00001000,
	0b00000100,
	0b00000010,
	0b11111111
};

uint8_t N0[8] = {
	0b00111100,
	0b01000010,
	0b10100001,
	0b10010001,
	0b10001001,
	0b10000101,
	0b01000010,
	0b00111100
};
uint8_t N1[8] = {
	0b00011000,
	0b00010100,
	0b00010010,
	0b00010000,
	0b00010000,
	0b00010000,
	0b00010000,
	0b01111110
};
uint8_t N2[8] = {
	0b00111100,
	0b01000010,
	0b01000000,
	0b00100000,
	0b00010000,
	0b00001000,
	0b00000100,
	0b01111110
};
uint8_t N3[8] = {
	0b00111100,
	0b01000010,
	0b01000000,
	0b00111000,
	0b01000000,
	0b01000000,
	0b01000010,
	0b00111100
};
uint8_t N4[8] = {
	0b00100000,
	0b00110000,
	0b00101000,
	0b00100100,
	0b00100010,
	0b01111110,
	0b00100000,
	0b00100000
};
uint8_t N5[8] = {
	0b01111110,
	0b00000010,
	0b00000010,
	0b00111110,
	0b01000000,
	0b01000000,
	0b01000010,
	0b00111100
};
uint8_t N6[8] = {
	0b00111100,
	0b00000010,
	0b00000001,
	0b00111111,
	0b01000001,
	0b01000001,
	0b01000010,
	0b00111100
};
uint8_t N7[8] = {
	0b01111110,
	0b01000000,
	0b00100000,
	0b00010000,
	0b00001000,
	0b00000100,
	0b00000100,
	0b00000100
};
uint8_t N8[8] = {
	0b00111100,
	0b01000010,
	0b01000010,
	0b00111100,
	0b01000010,
	0b01000010,
	0b01000010,
	0b00111100
};
uint8_t N9[8] = {
	0b00111100,
	0b01000010,
	0b01000010,
	0b01111100,
	0b01000000,
	0b01000000,
	0b00100000,
	0b00011100
};

uint8_t PUNTO[8] = {
	0b00000000,
	0b00000000,
	0b00000000,
	0b00000000,
	0b00000000,
	0b00000000,
	0b01100000,
	0b01100000
};

uint8_t* abecedario[26] = {
	A,B,C,D,E,F,G,H,I,J,K,L,M,
	N,O,P,Q,R,S,T,U,V,W,X,Y,Z
};
uint8_t* numeros[10] = {
	N0, N1, N2, N3, N4, N5, N6, N7, N8, N9
};

uint8_t* mensaje[19] = {
	H,O,L,A,M,U,N,D,O,
	PUNTO,PUNTO,PUNTO,
	N1,N1,N8,N2,N6,N6,N0
};

#define MENSAJE_LEN 19

void escribir_columna(uint8_t dato)
{
	PORTB = dato & 0b00111111;
	PORTC = (PORTC & 0b11111001) | ((dato & 0b11000000) >> 5);
}

uint8_t boton_presionado(void)
{
	if(!(PINC & (1 << PC0)))
	{
		_delay_ms(50);
		if(!(PINC & (1 << PC0)))
		{
			while(!(PINC & (1 << PC0)));
			return 1;
		}
	}
	return 0;
}

int main(void)
{
	uint8_t modo = 0;   // 0 = modo prueba, 1 = mens

	DDRD = 0xFF;
	DDRB = 0b00111111;   // PB0-PB5 salida
	DDRC |= (1 << PC1) | (1 << PC2);   // PC1 y PC2 salida
	DDRC &= ~(1 << PC0);     // A0 como entrada
	PORTC |= (1 << PC0);     // Pull-up activado

	// RUT ENCENDIDOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
	prender_columna();
	prender_fila();
	prender_todos();   

	while(1)
	{
		if (boton_presionado())
		{
			modo ^= 1;   // Cambia entre modo prueba y mensaje
		}

		if (modo == 0)
		{
			// MODO PRUEBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
			for(uint8_t i = 0; i < 26; i++)
			{
				mostrar_letra(abecedario[i], &modo);
				if (modo != 0) break;   // Salir si cambia de modo
			}
			if (modo != 0) continue;

			for(uint8_t i = 0; i < 10; i++)
			{
				mostrar_letra(numeros[i], &modo);
				if (modo != 0) break;   // Salir si cambia de modo
			}
		}
		else
		{
			// MENSAJE CORREDIZOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
			mostrar_mensaje(&modo);
		}
	}
}



// FUNCIONEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEES

void prender_columna(void)
{
	for(uint8_t columna = 0; columna < 8; columna++)
	{
		for(uint8_t fila = 0; fila < 8; fila++)
		{
			PORTD = ~(1 << fila);
			uint8_t dato = (1 << columna);

			escribir_columna(dato);
			_delay_ms(2);
		}
	}
}

void prender_fila(void)
{
	for(uint8_t fila = 0; fila < 8; fila++)
	{
		PORTD = ~(1 << fila);

		escribir_columna(0xFF);   // Todas la

		_delay_ms(100);
	}
}

void prender_todos(void)
{
	for(uint8_t t = 0; t < 150; t++)   
	{
		for(uint8_t fila = 0; fila < 8; fila++)
		{
			PORTD = ~(1 << fila);
			escribir_columna(0xFF);
			_delay_ms(1);
		}
	}
}

void mostrar_letra(uint8_t letra[], uint8_t *modo)
{
	for(uint16_t refresco = 0; refresco < 400; refresco++)
	{
		for(uint8_t fila = 0; fila < 8; fila++)
		{
			// Revisar boton sguido
			if(boton_presionado())
			{
				*modo ^= 1;
				return;   // salirenfa
			}

			PORTD = ~(1 << fila);
			escribir_columna(letra[fila]);
			_delay_us(400);
		}
	}
}

void mostrar_mensaje(uint8_t *modo)
{
	for(uint16_t pos = 0; pos < (uint16_t)(MENSAJE_LEN * 8) + 8; pos++)
	{
		for(uint8_t refresco = 0; refresco < 20; refresco++)
		{
			for(uint8_t fila = 0; fila < 8; fila++)
			{
				// Revisar boton constantemente
				if(boton_presionado())
				{
					*modo ^= 1;
					return;   // salir inmediatamente
				}

				PORTD = ~(1 << fila);
				uint8_t dato = 0;

				// Calcular que columna del mensaje corresponde a cada columna de pantalla
				for(uint8_t col_pantalla = 0; col_pantalla < 8; col_pantalla++)
				{
					int16_t col_msg = (int16_t)pos - (7 - col_pantalla);
					if(col_msg >= 0 && col_msg < (int16_t)(MENSAJE_LEN * 8))
					{
						uint8_t idx_letra = col_msg / 8;
						uint8_t col_letra  = col_msg % 8;
						uint8_t pixel      = (mensaje[idx_letra][fila] >> col_letra) & 1;
						dato |= (pixel << col_pantalla);
					}
				}

				escribir_columna(dato);
				_delay_us(400);
			}
		}
	}
}