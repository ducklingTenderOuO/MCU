#include "LCD.h"

void lcd_init(void)
{
	// Configurar pines como salidas
	DATA_DDR |= (1<<LCD_D7)|(1<<LCD_D6)|(1<<LCD_D5)|(1<<LCD_D4);
	CTL_DDR |= (1<<LCD_EN)|(1<<LCD_RS);
	
	_delay_ms(50); // Tiempo de estabilizaci�n despu�s de encender
	
	// Secuencia de inicializaci�n en modo 4 bits
	// Primer nibble: 0x3
	DATA_BUS = (DATA_BUS & 0x03) | (0x30);  // Mantener bits bajos
	CTL_BUS &= ~(1<<LCD_RS);  // Modo comando
	CTL_BUS |= (1<<LCD_EN);
	_delay_ms(5);
	CTL_BUS &= ~(1<<LCD_EN);
	_delay_ms(5);
	
	// Segundo nibble: 0x3
	CTL_BUS |= (1<<LCD_EN);
	_delay_ms(5);
	CTL_BUS &= ~(1<<LCD_EN);
	_delay_ms(5);
	
	// Tercer nibble: 0x3
	CTL_BUS |= (1<<LCD_EN);
	_delay_ms(5);
	CTL_BUS &= ~(1<<LCD_EN);
	_delay_ms(5);
	
	// Finalmente configurar a modo 4 bits: 0x2
	DATA_BUS = (DATA_BUS & 0x03) | (0x20);
	CTL_BUS |= (1<<LCD_EN);
	_delay_ms(5);
	CTL_BUS &= ~(1<<LCD_EN);
	_delay_ms(5);
	
	// Ahora configurar el LCD
	lcd_send_command(LCD_CMD_4BIT_2ROW_5X7);
	_delay_ms(5);
	lcd_send_command(LCD_CMD_DISPLAY_CURSOR_BLINK);
	_delay_ms(5);
	lcd_send_command(LCD_CMD_CLEAR_DISPLAY);
	_delay_ms(5);
}

void lcd_send_command(uint8_t command)
{
	// Enviar nibble alto
	DATA_BUS = (DATA_BUS & 0x03) | (command & 0xF0);
	CTL_BUS &= ~(1<<LCD_RS);  // RS = 0 para comando
	
	CTL_BUS |= (1<<LCD_EN);
	_delay_us(1);
	CTL_BUS &= ~(1<<LCD_EN);
	_delay_us(50);
	
	// Enviar nibble bajo
	DATA_BUS = (DATA_BUS & 0x03) | ((command << 4) & 0xF0);
	
	CTL_BUS |= (1<<LCD_EN);
	_delay_us(1);
	CTL_BUS &= ~(1<<LCD_EN);
	_delay_ms(2);
}

void lcd_write_character(uint8_t character)
{
	// Enviar nibble alto
	DATA_BUS = (DATA_BUS & 0x03) | (character & 0xF0);
	CTL_BUS |= (1<<LCD_RS);  // RS = 1 para datos
	
	CTL_BUS |= (1<<LCD_EN);
	_delay_us(1);
	CTL_BUS &= ~(1<<LCD_EN);
	_delay_us(50);
	
	// Enviar nibble bajo
	DATA_BUS = (DATA_BUS & 0x03) | ((character << 4) & 0xF0);
	
	CTL_BUS |= (1<<LCD_EN);
	_delay_us(1);
	CTL_BUS &= ~(1<<LCD_EN);
	_delay_ms(2);
}

void lcd_write_word(uint8_t word[])
{
	int i = 0;
	while(word[i] != '\0')
	{
		lcd_write_character(word[i]);
		i++;
	}
}

void lcd_clear(void)
{
	lcd_send_command(LCD_CMD_CLEAR_DISPLAY);
	_delay_ms(5);
}

void lcd_goto_xy(uint8_t row, uint8_t col)
{
	uint8_t address;
	if(row == 0)
	address = 0x00 + col;
	else
	address = 0x40 + col;
	lcd_send_command(0x80 | address);
}

// Funciones adicionales �tiles
void lcd_print(char* str)
{
	while(*str)
	{
		lcd_write_character(*str++);
	}
}

void lcd_print_int(long num)
{
	char buffer[12];
	int i = 0;
	
	if(num == 0)
	{
		lcd_write_character('0');
		return;
	}
	
	if(num < 0)
	{
		lcd_write_character('-');
		num = -num;
	}
	
	while(num > 0 && i < 11)
	{
		buffer[i++] = '0' + (num % 10);
		num /= 10;
	}
	
	while(i > 0)
	{
		lcd_write_character(buffer[--i]);
	}
}