﻿/*
 * MC_P4.c
 *
 * Created: 05/03/2026 02:11:08 p. m.
 * Author : astri
 */ 

#ifndef F_CPU
#  define F_CPU 16000000UL
#endif

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdbool.h>   /* true / false / bool */
#include <stdint.h>
#include "LCD.h"


static const char teclas[4][4] = {
	{'1','2','3','+'},
	{'4','5','6','-'},
	{'7','8','9','x'},
	{'*','0','#','/'}
};

volatile bool teclaPendiente = false;

ISR(PCINT2_vect) {
	teclaPendiente = true;
}

static long long numero1      = 0;
static long long numero2      = 0;
static long long resultado    = 0;
static int       decResultado = 0;
static char      operacion    = 0;
static bool      segundoNumero  = false;
static bool      hayError       = false;
static bool      digitIngresado = false;

static void fila_set(uint8_t f, uint8_t val) {
	switch (f) {
		case 0: /* PB1 */
		if (val) PORTB |=  (1 << PB1);
		else     PORTB &= ~(1 << PB1);
		break;
		case 1: /* PB0 */
		if (val) PORTB |=  (1 << PB0);
		else     PORTB &= ~(1 << PB0);
		break;
		case 2: /* PD7 */
		if (val) PORTD |=  (1 << PD7);
		else     PORTD &= ~(1 << PD7);
		break;
		case 3: /* PD6 */
		if (val) PORTD |=  (1 << PD6);
		else     PORTD &= ~(1 << PD6);
		break;
	}
}

static uint8_t col_leer(uint8_t c) {
	switch (c) {
		case 0: return (PIND >> PD5) & 1;
		case 1: return (PIND >> PD4) & 1;
		case 2: return (PIND >> PD3) & 1;
		case 3: return (PIND >> PD2) & 1;
	}
	return 1;
}

static void setupTeclado(void) {
	
	DDRB  |=  (1 << PB1) | (1 << PB0);
	PORTB &= ~((1 << PB1) | (1 << PB0));
	DDRD  |=  (1 << PD7) | (1 << PD6);
	PORTD &= ~((1 << PD7) | (1 << PD6));

	
	DDRD  &= ~((1 << PD5) | (1 << PD4) | (1 << PD3) | (1 << PD2));
	PORTD |=   (1 << PD5) | (1 << PD4) | (1 << PD3) | (1 << PD2);

	PCICR  |= (1 << PCIE2);
	PCMSK2 |= (1 << PCINT18) | (1 << PCINT19)
	| (1 << PCINT20) | (1 << PCINT21);
}

static char escanearTeclado(void) {
	_delay_ms(20); /* debounce bajada */

	for (uint8_t f = 0; f < 4; f++) {
		/* Poner todas las filas HIGH y bajar solo la actual */
		for (uint8_t i = 0; i < 4; i++) fila_set(i, 1);
		fila_set(f, 0);
		_delay_us(10);

		for (uint8_t c = 0; c < 4; c++) {
			if (col_leer(c) == 0) {
				while (col_leer(c) == 0); /* esperar soltar */
				_delay_ms(20);            /* debounce subida */
				for (uint8_t i = 0; i < 4; i++) fila_set(i, 0); /* reposo */
				return teclas[f][c];
			}
		}
	}
	for (uint8_t i = 0; i < 4; i++) fila_set(i, 0); /* reposo — falsa alarma */
	return 0;
}

// ─── Helpers LCD ──────────────────────────────────────────────────────────────
static void lcdPrintInt(int num) {
	if (num == 0) { lcd_write_character('0'); return; }
	char buf[6]; int i = 0;
	while (num > 0) { buf[i++] = '0' + (num % 10); num /= 10; }
	for (int j = i - 1; j >= 0; j--) lcd_write_character(buf[j]);
}

static void lcdPrintLL(long long num) {
	if (num == 0) { lcd_write_character('0'); return; }
	char buf[21]; int i = 0;
	while (num > 0) { buf[i++] = '0' + (int)(num % 10); num /= 10; }
	for (int j = i - 1; j >= 0; j--) lcd_write_character(buf[j]);
}

static int contarDigitos(long long num) {
	if (num == 0) return 1;
	int d = 0;
	while (num > 0) { d++; num /= 10; }
	return d;
}

static void mostrarError(void) {
	lcd_clear();
	lcd_goto_xy(0, 0);
	lcd_write_word((uint8_t *)"Error");
	hayError = true;
}

static void lcdPrintResultado(void) {
	long long absRes = resultado < 0 ? -resultado : resultado;
	int totalChars   = contarDigitos(absRes) + 3 + (resultado < 0 ? 1 : 0);
	if (totalChars > 16) { mostrarError(); return; }
	if (resultado < 0) lcd_write_character('-');
	lcdPrintLL(absRes);
	lcd_write_character('.');
	if (decResultado < 10) lcd_write_character('0');
	lcdPrintInt(decResultado);
}

// ─── Lógica de cálculo ────────────────────────────────────────────────────────
static void calcular(void) {
	decResultado = 0;
	switch (operacion) {
		case '+': resultado = numero1 + numero2; break;
		case '-': resultado = numero1 - numero2; break;
		case 'x': resultado = numero1 * numero2; break;
		case '/':
		if (numero2 == 0) { mostrarError(); return; }
		{
			long long a = numero1 < 0 ? -numero1 : numero1;
			long long b = numero2 < 0 ? -numero2 : numero2;
			resultado    = numero1 / numero2;
			decResultado = (int)((a % b) * 100 / b);
		}
		break;
	}
	numero1 = resultado;
	numero2 = 0;
}

static void resetear(void) {
	numero1 = numero2 = resultado = 0;
	decResultado   = 0;
	operacion      = 0;
	segundoNumero  = false;
	hayError       = false;
	digitIngresado = false;
}

// ─────────────────────────────────────────────────────────────────────────────
int main(void) {
	lcd_init();
	lcd_goto_xy(0, 0);
	lcd_write_word((uint8_t *)"Calculadora");
	setupTeclado();
	sei(); /* habilitar interrupciones globales */
	_delay_ms(2000);
	lcd_clear();

	while (1) {
		if (!teclaPendiente) continue;
		teclaPendiente = false;

		char tecla = escanearTeclado();
		if (!tecla) continue;

		if (hayError) {
			if (tecla == '*') { resetear(); lcd_clear(); }
			continue;
		}

		/* ── NÚMEROS ────────────────────────────────────────────────────── */
		if (tecla >= '0' && tecla <= '9') {
			if (!segundoNumero) numero1 = numero1 * 10 + (tecla - '0');
			else                numero2 = numero2 * 10 + (tecla - '0');
			digitIngresado = true;
			lcd_write_character(tecla);
		}

		/* ── OPERACIONES ────────────────────────────────────────────────── */
		else if (tecla == '+' || tecla == '-' || tecla == 'x' || tecla == '/') {
			if (segundoNumero && !digitIngresado) { mostrarError(); continue; }
			if (segundoNumero && digitIngresado) {
				calcular();
				if (hayError) continue;
				lcd_clear(); lcd_goto_xy(0,0); lcdPrintResultado();
			}
			operacion      = tecla;
			segundoNumero  = true;
			digitIngresado = false;
			lcd_write_character(tecla);
		}

		/* ── IGUAL ──────────────────────────────────────────────────────── */
		else if (tecla == '#') {
			if (operacion == 0 || !digitIngresado) { mostrarError(); continue; }
			calcular();
			if (hayError) continue;
			lcd_clear(); lcd_goto_xy(0,0); lcdPrintResultado();
			segundoNumero  = false;
			digitIngresado = false;
		}

		/* ── LIMPIAR ────────────────────────────────────────────────────── */
		else if (tecla == '*') {
			resetear();
			lcd_clear();
		}
	}
}