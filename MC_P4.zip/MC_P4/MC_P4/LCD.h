﻿/*
 * IncFile1.h
 *
 * Created: 11/03/2026 03:11:58 p. m.
 *  Author: astri
 */ 

#ifndef LCD_H_
#define LCD_H_
#ifndef F_CPU
#  define F_CPU 16000000UL
#endif

#include <avr/io.h>
#include <util/delay.h>

#define LCD_RS_PORT   PORTB
#define LCD_RS_DDR    DDRB
#define LCD_RS        PB5

#define LCD_EN_PORT   PORTB
#define LCD_EN_DDR    DDRB
#define LCD_EN        PB4

#define LCD_D4_PORT   PORTB
#define LCD_D4_DDR    DDRB
#define LCD_D4        PB3

#define LCD_D5_PORT   PORTB
#define LCD_D5_DDR    DDRB
#define LCD_D5        PB2

#define LCD_D6_PORT   PORTC
#define LCD_D6_DDR    DDRC
#define LCD_D6        PC0

#define LCD_D7_PORT   PORTC
#define LCD_D7_DDR    DDRC
#define LCD_D7        PC1

// Comandos básicos
#define LCD_CMD_CLEAR_DISPLAY           0x01
#define LCD_CMD_CURSOR_HOME             0x02

// Display control
#define LCD_CMD_DISPLAY_OFF             0x08
#define LCD_CMD_DISPLAY_NO_CURSOR       0x0C
#define LCD_CMD_DISPLAY_CURSOR_NO_BLINK 0x0E
#define LCD_CMD_DISPLAY_CURSOR_BLINK    0x0F

// Function set
#define LCD_CMD_4BIT_2ROW_5X7           0x28
#define LCD_CMD_8BIT_2ROW_5X7           0x38

// ─── Prototipos envueltos en extern "C" para compilación con C++ (Arduino IDE) ──
#ifdef __cplusplus
extern "C" {
#endif

void lcd_init(void);
void lcd_send_command(uint8_t command);
void lcd_write_character(uint8_t character);
void lcd_write_word(uint8_t word[]);
void lcd_clear(void);
void lcd_goto_xy(uint8_t row, uint8_t col);

#ifdef __cplusplus
}
#endif

#endif /* LCD_H_ */