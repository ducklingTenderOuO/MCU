/*
 * CFile1.c
 *
 * Created: 11/03/2026 03:12:30 p. m.
 *  Author: astri
 */ 

#include "LCD.h"

static void set_pin(volatile uint8_t *port, uint8_t pin, uint8_t val) {
	if (val) *port |=  (1 << pin);
	else     *port &= ~(1 << pin);
}

static void pulse_en(void) {
	LCD_EN_PORT |=  (1 << LCD_EN);
	_delay_us(1);
	LCD_EN_PORT &= ~(1 << LCD_EN);
	_delay_us(50);
}

// Env�a 4 bits (nibble alto o bajo de un byte)
static void send_nibble(uint8_t nibble) {
	set_pin(&LCD_D4_PORT, LCD_D4, (nibble >> 0) & 1);
	set_pin(&LCD_D5_PORT, LCD_D5, (nibble >> 1) & 1);
	set_pin(&LCD_D6_PORT, LCD_D6, (nibble >> 2) & 1);
	set_pin(&LCD_D7_PORT, LCD_D7, (nibble >> 3) & 1);
	pulse_en();
}

// Env�a un byte completo en modo 4 bits (nibble alto primero)
// mode: 0 = comando, 1 = dato
static void lcd_send(uint8_t byte, uint8_t mode) {
	set_pin(&LCD_RS_PORT, LCD_RS, mode);
	send_nibble(byte >> 4);
	send_nibble(byte & 0x0F);
	_delay_ms(2);
}

void lcd_init(void) {
	// Configurar todos los pines como salida
	LCD_RS_DDR |= (1 << LCD_RS);
	LCD_EN_DDR |= (1 << LCD_EN);
	LCD_D4_DDR |= (1 << LCD_D4);
	LCD_D5_DDR |= (1 << LCD_D5);
	LCD_D6_DDR |= (1 << LCD_D6);
	LCD_D7_DDR |= (1 << LCD_D7);

	_delay_ms(50);

	// Secuencia de inicializaci�n en modo 4 bits (datasheet HD44780)
	LCD_RS_PORT &= ~(1 << LCD_RS);   // RS = 0
	send_nibble(0x03); _delay_ms(5);
	send_nibble(0x03); _delay_us(150);
	send_nibble(0x03); _delay_us(150);
	send_nibble(0x02);               // Cambiar a modo 4 bits

	lcd_send_command(LCD_CMD_4BIT_2ROW_5X7);
	lcd_send_command(LCD_CMD_DISPLAY_NO_CURSOR);
	lcd_send_command(0x06);          // Modo entrada: incrementar, no desplazar
	lcd_send_command(LCD_CMD_CLEAR_DISPLAY);
	_delay_ms(5);                    // CLEAR necesita hasta 1.52 ms; usamos 5 ms
	lcd_send_command(LCD_CMD_CURSOR_HOME);
	_delay_ms(5);                    // HOME tambi�n es lento
}

void lcd_send_command(uint8_t command) {
	lcd_send(command, 0);
}

void lcd_write_character(uint8_t character) {
	lcd_send(character, 1);
}

void lcd_write_word(uint8_t word[]) {
	int i = 0;
	while (word[i] != '\0') {
		lcd_write_character(word[i]);
		i++;
	}
}

void lcd_clear(void) {
	lcd_send_command(LCD_CMD_CLEAR_DISPLAY);
	_delay_ms(5);
	lcd_send_command(LCD_CMD_CURSOR_HOME);
	_delay_ms(5);
}

void lcd_goto_xy(uint8_t row, uint8_t col) {
	lcd_send_command(0x80 | (row << 6) | col);
	_delay_us(50);
}