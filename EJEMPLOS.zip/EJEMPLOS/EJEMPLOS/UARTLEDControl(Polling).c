#include <avr/io.h>
#include "UART.h"

int main(void)
{
	// Configure PortD I/O SFRs
	DDRD |= 0b11000000; // D6-D7 as Output
	// Initialize UART module
	UART_init(); // D:8bit/P:None/Sp:1bit/9600B
	// Print Instructions to UART Port
	UART_string("Press 1 2 to turn on\n\r");
	UART_string("Press 4 5 to turn off\n\r");

	uint8_t dato = 0;

	while (1)
	{
		dato = UART_read();

		if(dato != 0)
		{
			switch(dato)
			{
				case '1':
				UART_string("LED1 ON\n\r");
				PORTD |= (1<<PIND6);
				break;
				case '2':
				UART_string("LED2 ON\n\r");
				PORTD |= (1<<PIND7);
				break;
				case '4':
				UART_string("LED1 OFF\n\r");
				PORTD &= ~(1<<PIND6);
				break;
				case '5':
				UART_string("LED2 OFF\n\r");
				PORTD &= ~(1<<PIND7);
				break;
				default:
				UART_string("INVALID\n\r");
				break;
			}
		}
	}
}