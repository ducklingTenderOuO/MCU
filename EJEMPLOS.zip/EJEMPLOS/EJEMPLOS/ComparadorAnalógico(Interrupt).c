﻿/*
 * ComparadorAnalógico_Interrupt_.c
 *
 * Created: 16/04/2026 01:53:47 p. m.
 *  Author: astri
 */ 

#include <avr/interrupt.h>

int main(void)
{
	// Configure PortB I/O SFRs
	DDRB |= 0b00000111; // B0, B1, B2 as Digital Outputs
	
	// Analog Comparator Config.
	ACSR |= (0<<ACD);   // Analog Comparator Disable (0=Enable)
	ACSR |= (0<<ACBG);  // Bandgap Select (0=AIN0/AIN1)
	ACSR |= (1<<ACIE);  // Interrupt Enable
	ACSR |= (0<<ACIC);  // Input Capture Enable
	ACSR |= (0<<ACIS1)|(0<<ACIS0); // Interrupt Mode: Toggle
	DIDR1 |= (1<<AIN1D)|(1<<AIN0D); // Digital Input Disable

	sei(); // Enable Global Interrupt Mask

	while (1);
}

ISR(ANALOG_COMP_vect)
{
	// Put the Analog Comparator Output to PINB0
	PORTB = (ACSR >> ACO) & 0x01;
}