/*
 * EJEMPLOS.c
 *
 * Created: 12/03/2026 02:09:16 a. m.
 * Author : astri
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

