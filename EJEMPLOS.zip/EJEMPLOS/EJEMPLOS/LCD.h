#ifndef LCD_H_
#define LCD_H_

#include <avr/io.h>
#include <util/delay.h>

// Configuraci�n de pines
#define DATA_BUS    PORTC
#define CTL_BUS     PORTC
#define DATA_DDR    DDRC
#define CTL_DDR     DDRC
#define LCD_RS      PC0      
#define LCD_EN      PC1      
#define LCD_D4      PC2      
#define LCD_D5      PC3      
#define LCD_D6      PC4      
#define LCD_D7      PC5      

// Comandos b�sicos
#define LCD_CMD_CLEAR_DISPLAY   0x01
#define LCD_CMD_CURSOR_HOME     0x02

// Display control
#define LCD_CMD_DISPLAY_OFF             0x08
#define LCD_CMD_DISPLAY_NO_CURSOR       0x0C
#define LCD_CMD_DISPLAY_CURSOR_NO_BLINK 0x0E
#define LCD_CMD_DISPLAY_CURSOR_BLINK    0x0F

// Function set
#define LCD_CMD_4BIT_2ROW_5X7  0x28
#define LCD_CMD_8BIT_2ROW_5X7  0x38

// Prototipos de funciones
void lcd_init(void);
void lcd_send_command(uint8_t command);
void lcd_write_character(uint8_t character);
void lcd_write_word(uint8_t word[]);
void lcd_clear(void);
void lcd_goto_xy(uint8_t row, uint8_t col);
void lcd_print(char* str);  // Funci�n adicional �til
void lcd_print_int(long num); // Para imprimir n�meros

#endif /* LCD_H_ */