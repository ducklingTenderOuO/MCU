#include <avr/io.h>
#include <stdbool.h>
#include <avr/interrupt.h>
#include "UART.h"

bool RxFlag = false;

int main(void)
{
	// Configure PortD I/O SFRs
	DDRD |= 0b11000000; // PinD6-D7 as Outputs
	UART_init(); // D:8bit/P:None/Sp:1bit/9600B
	sei(); // Enable Global Interrupt Mask

	UART_string("Press 1 2 to turn on\n\r");
	UART_string("Press 4 5 to turn off\n\r");

	uint8_t dato = 0;

	while (1)
	{
		if (RxFlag)
		{
			dato = UART_read();
			RxFlag = false;

			switch(dato)
			{
				case '1':
				UART_string("LED1 ON\n\r");
				PORTD |= (1<<PIND6);
				break;
				case '2':
				UART_string("LED2 ON\n\r");
				PORTD |= (1<<PIND7);
				break;
				case '4':
				UART_string("LED1 OFF\n\r");
				PORTD &= ~(1<<PIND6);
				break;
				case '5':
				UART_string("LED2 OFF\n\r");
				PORTD &= ~(1<<PIND7);
				break;
				default:
				UART_string("INVALID\n\r");
				break;
			}
		}
	}
}

ISR(USART_RX_vect)
{
	if (!RxFlag)
	{
		RxFlag = true;
	}
}