/*
 * CFile1.c
 *
 * Created: 16/04/2026 01:53:00 p. m.
 *  Author: astri
 */ 

#include <avr/io.h>

int main(void)
{
	// Configure PortB I/O SFRs
	DDRB |= 0b00000001; // B0 as Digital Output
	
	// Analog Comparator Config.
	ACSR |= (0<<ACD);   // Analog Comparator Disable (0=Enable)
	ACSR |= (0<<ACBG);  // Bandgap Select (0=AIN0/AIN1)
	ACSR |= (0<<ACIE);  // Interrupt Enable
	ACSR |= (0<<ACIC);  // Input Capture Enable
	ACSR |= (0<<ACIS1)|(0<<ACIS0); // Interrupt Mode (00=Toggle)
	DIDR1 |= (1<<AIN1D)|(1<<AIN0D); // Digital Input Disable

	while (1)
	{
		// Put the Analog Comparator Output to PINB0
		PORTB = (ACSR >> ACO) & 0x01;
	}
}