
/*
 * SPI.c
 *
 * Created: 29/04/2026 11:08:41 a. m.
 *  Author: astri
 */ 

#include "SPI.h"

void SPI_MasterInit(void)
{
	/* Set SS, MOSI and SCK as Output */
	DDRB |= (1<<PINB2)|(1<<PINB3)|(1<<PINB5);
	DDRB &= ~(1<<PINB4); // MISO as Input
	/* Set SPI Mode as 0 */
	SPCR |= (0<<CPOL)|(0<<CPHA);
	/* Set Data Order as MSB first */
	SPCR |= (0<<DORD);
	/* Set clock rate fck/2 */
	SPCR |= (0<<SPR1)|(0<<SPR0);
	/* Enable SPI as Master */
	SPCR |= (1<<SPE)|(1<<MSTR);
	/* Set clock rate fck/2 (double speed) */
	SPSR |= (1<<SPI2X);
	/* Set SPI Interrupt Enable (disabled) */
	SPCR |= (0<<SPIE);
}

void SPI_MasterTransmit(char cData)
{
	/* Start transmission */
	SPDR = cData;
	/* Wait for transmission complete */
	while(!(SPSR & (1<<SPIF)));
}