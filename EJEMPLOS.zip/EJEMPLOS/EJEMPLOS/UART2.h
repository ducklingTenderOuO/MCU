#ifndef UART_H_
#define UART_H_

void UART_init(); // Initialize: Async/D: 8bit/S: 1bit/9600B
unsigned char UART_read();    // Data read function
void UART_write(unsigned char); // Data write function
void UART_string(char*);    // String write function

void UART_init()
{
	UCSR0A = (0<<U2X0); // Double USART Speed Disabled
	UCSR0A = (0<<MPCM0); // Multiprocessor Mode Disabled
	UCSR0B = (1<<TXEN0); // Tx Enable
	UCSR0B = (1<<RXEN0); // Rx Enable
	UCSR0B = (0<<UDRIE0); // Data Register Empty IntEn
	UCSR0B = (0<<TXCIE0); // Tx Complete IntEn
	UCSR0B = (1<<RXCIE0); // Rx Complete IntEn
	UCSR0C = (0<<UMSEL01) | (0<<UMSEL00); // Mode: 00=Asynchronous
	UCSR0C = (0<<UPM01) | (0<<UPM00); // Parity Mode: 00=None
	UCSR0C = (0<<USBS0); // Stop bit: 0=1-bit
	UCSR0C = (1<<UCSZ01) | (1<<UCSZ00); // Data Size: 11=8-bit
	UCSR0C = (0<<UCPOL0); // Clock Polarity: 0 for Async.
	UBRR0 = 103; // Baud rate: 103=9600B at 16MHz
}

unsigned char UART_read()
{
	if(UCSR0A & (1<<RXC0)) // If Rx Complete Flag in UCSR0A is set
	{
		return UDR0; // Return received data in UDR0
	}
	return 0; // Else: return 0
}

void UART_write(unsigned char data)
{
	while(!(UCSR0A & (1<<UDRE0))); // While Data Register is not Empty
	UDR0 = data; // Put data into buffer, sends the data
}

void UART_string(char* string)
{
	while(*string != 0) // While the last value is not null
	{
		UART_write(*string); // Send the next character in the string
		string++; // Add one to the string address
	}
}

#endif /* UART_H_ */