/*
 * Leervoltajevariable_Interrupt_.c
 *
 * Created: 16/04/2026 01:55:24 p. m.
 *  Author: astri
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>
#include "UART.h"

volatile int ADC_value;

int main(void)
{
	// ADC Configuration
	ADMUX |= (0<<REFS1)|(0<<REFS0); // 00: AREF, 01: AVCC, 11: Internal 1.1V
	ADMUX |= (0<<MUX3)|(0<<MUX2)|(0<<MUX1)|(0<<MUX0); // ADC0/PINC0
	DIDR0 |= (1<<ADC0D); // Turn-off ADC0 digital pin logic
	ADCSRB |= (0<<ADTS2)|(0<<ADTS1)|(0<<ADTS0); // Free Running Mode
	ADCSRA |= (1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0); // Prescaler = 128
	ADCSRA |= (1<<ADATE); // Auto Trigger Enable
	ADCSRA |= (1<<ADIE); // ADC Interrupt Enable
	ADCSRA |= (1<<ADEN); // ADC Enable
	sei(); // Global Interrupt Enable

	// Initialize UART module
	UART_init(); // D:8bit/P:None/Sp:1bit/9600B

	float ADC_fvalue;
	char adc_str[20];

	ADCSRA |= (1<<ADSC); // Start the first conversion

	while (1)
	{
		ADC_fvalue = (ADC_value * 5.0) / 1024.0;
		sprintf(adc_str, "ADC Value=%.2fV \r", ADC_fvalue); // To String
		UART_string(adc_str); // Write to UART
		_delay_ms(250);
	}
}

ISR(ADC_vect)
{
	ADC_value = ADC; // Read ADC result in interrupt
}