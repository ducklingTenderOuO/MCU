/*
 * Leervoltajevariable_Polling_.c
 *
 * Created: 16/04/2026 01:54:49 p. m.
 *  Author: astri
 */ 

#define F_CPU 16000000L
#include <avr/io.h>
#include <stdio.h>
#include <util/delay.h>
#include "UART.h"

int main()
{
	// ADC Configuration
	ADMUX |= (0<<REFS1)|(0<<REFS0); // 00: AREF/AVCC, 01: AVCC, 11: Internal 1.1V
	ADMUX |= (0<<MUX3)|(0<<MUX2)|(0<<MUX1)|(0<<MUX0); // ADC0/PINC0
	ADCSRA |= (1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0); // Prescaler = 128
	DIDR0 |= (1<<ADC0D); // Turn-off ADC0 digital pin logic
	ADCSRA |= (1<<ADEN); // ADC Enable
	
	// Initialize UART module
	UART_init(); // D:8bit/P:None/Sp:1bit/9600B
	
	// ADC: 10-bit ADC Data Variables
	float ADC_value = 0.0;
	char adc_str[20];

	while (1)
	{
		ADCSRA |= (1<<ADSC); // Start the conversion
		while(!(ADCSRA & (1<<ADIF))); // Wait for the conversion
		ADCSRA |= (1<<ADIF); // Clear the flag
		ADC_value = (ADC * 5.0) / 1024.0;
		sprintf(adc_str, "ADC Value=%.2fV \r", ADC_value); // to String
		UART_string(adc_str); // Write to UART
		_delay_ms(250);
	}
}