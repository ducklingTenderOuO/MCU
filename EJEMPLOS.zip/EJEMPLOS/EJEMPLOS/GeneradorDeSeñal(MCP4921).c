﻿
/*
 * GeneradorDeSeñal_MCP4921_.c
 *
 * Created: 29/04/2026 11:11:16 a. m.
 *  Author: astri
 */ 

#include <avr/io.h>
#include "SPI.h"

void DAC_Output(uint16_t value)
{
	// 0:DACA; 0:BUFF; 1:GA(1x); 1:EN
	uint8_t data_high = 0b00110000;
	data_high |= (0x0F & (value >> 8));
	uint8_t data_low = (uint8_t)value;
	
	PORTB &= ~(1 << PINB2); // SS = LOW
	SPI_MasterTransmit(data_high);
	SPI_MasterTransmit(data_low);
	PORTB |= (1 << PINB2);  // SS = HIGH
}

int main(void)
{
	// Initialize SPI Module
	SPI_MasterInit();
	
	// Counter for Sawtooth Wave
	uint16_t counter = 0;

	while (1)
	{
		DAC_Output(counter);
		counter++;
		if (counter > 4095) counter = 0;
	}
}