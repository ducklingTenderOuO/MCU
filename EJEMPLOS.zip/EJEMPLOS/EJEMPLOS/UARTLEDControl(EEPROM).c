#include <avr/io.h>
#include "UART.h"
#include "EEPROM.h"

int main(void)
{
	// Configure PortD I/O SFRs
	DDRD |= 0b11000000; // PinD6-D7 as Outputs
	UART_init(); // D:8bit/P:None/Sp:1bit/9600B

	if (EEPROM_read(0) == 1) PORTD |= (1<<PIND6);
	if (EEPROM_read(1) == 1) PORTD |= (1<<PIND7);

	UART_string("Press 1 2 to turn on\n\r");
	UART_string("Press 4 5 to turn off\n\r");

	uint8_t dato = 0;

	while (1)
	{
		dato = UART_read();
		if (dato != 0)
		{
			switch(dato)
			{
				case '1':
				UART_string("LED1 ON\n\r");
				PORTD |= (1<<PIND6);
				EEPROM_write(0, 1);
				break;
				case '2':
				UART_string("LED2 ON\n\r");
				PORTD |= (1<<PIND7);
				EEPROM_write(1, 1);
				break;
				case '4':
				UART_string("LED1 OFF\n\r");
				PORTD &= ~(1<<PIND6);
				EEPROM_write(0, 0);
				break;
				case '5':
				UART_string("LED2 OFF\n\r");
				PORTD &= ~(1<<PIND7);
				EEPROM_write(1, 0);
				break;
				default:
				UART_string("INVALID\n\r");
				break;
			}
		}
	}
}