#define F_CPU 16000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdint.h>
#include <stdio.h>

#define LED_GRN_PIN   PD5
#define LED_YLW_PIN   PD6
#define LED_RED_PIN   PD7
#define BUZZER_PIN    PB1
#define BTN_PIN       PB0

#define PHOTO_CH      0
#define N_MUESTRAS    20

#define BZ_RAPIDO_ON   100
#define BZ_RAPIDO_OFF  100
#define BZ_MEDIO_ON    350
#define BZ_MEDIO_OFF   350
#define BZ_LENTO_ON    800
#define BZ_LENTO_OFF   800

#define BUZ_OCR       999

volatile uint8_t  g_audio_habilitado = 1;
volatile uint16_t g_bz_on_ms         = 0;
volatile uint16_t g_bz_off_ms        = 0;
volatile uint16_t g_bz_contador      = 0;
volatile uint8_t  g_bz_fase          = 0;

void uart_init(void)
{
	UBRR0H = 0;
	UBRR0L = 103;
	UCSR0B = (1 << TXEN0);
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

void uart_write(char c)
{
	while (!(UCSR0A & (1 << UDRE0)));
	UDR0 = c;
}

void uart_print(const char *str)
{
	while (*str)
	uart_write(*str++);
}

ISR(TIMER0_COMPA_vect)
{
	g_bz_contador++;

	if (!g_audio_habilitado || g_bz_on_ms == 0)
	{
		TCCR1A &= ~(1 << COM1A0);
		PORTB  &= ~(1 << BUZZER_PIN);
		g_bz_contador = 0;
		g_bz_fase     = 0;
		return;
	}

	if (g_bz_fase == 1)
	{
		if (g_bz_contador >= g_bz_on_ms)
		{
			TCCR1A &= ~(1 << COM1A0);
			PORTB  &= ~(1 << BUZZER_PIN);
			g_bz_fase     = 0;
			g_bz_contador = 0;
		}
	}
	else
	{
		if (g_bz_contador >= g_bz_off_ms)
		{
			TCCR1A |= (1 << COM1A0);
			g_bz_fase     = 1;
			g_bz_contador = 0;
		}
	}
}

static void gpio_init(void)
{
	DDRD  |=  (1 << LED_GRN_PIN) | (1 << LED_YLW_PIN) | (1 << LED_RED_PIN);
	PORTD &= ~((1 << LED_GRN_PIN) | (1 << LED_YLW_PIN) | (1 << LED_RED_PIN));

	DDRB  |=  (1 << BUZZER_PIN);
	PORTB &= ~(1 << BUZZER_PIN);

	DDRB  &= ~(1 << BTN_PIN);
	PORTB |=  (1 << BTN_PIN);
}

static void adc_init(void)
{
	ADMUX  = (1 << REFS0);
	ADCSRA = (1 << ADEN)  |
	(1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
	DIDR0 |= (1 << ADC0D);
	ADCSRA |= (1 << ADSC);
	while (ADCSRA & (1 << ADSC));
}

static void timer0_init(void)
{
	TCCR0A = (1 << WGM01);
	TCCR0B = (1 << CS01) | (1 << CS00);
	OCR0A  = 249;
	TIMSK0 = (1 << OCIE0A);
}

static void timer1_init(void)
{
	TCCR1A = 0;
	TCCR1B = (1 << WGM12) | (1 << CS11);
	OCR1A  = BUZ_OCR;
}

static uint16_t adc_leer(uint8_t canal)
{
	ADMUX   = (ADMUX & 0xF0) | (canal & 0x0F);
	ADCSRA |= (1 << ADSC);
	while (ADCSRA & (1 << ADSC));
	return ADC;
}

static uint16_t adc_promedio(uint8_t canal)
{
	uint32_t suma = 0;
	for (uint8_t i = 0; i < N_MUESTRAS; i++)
	{
		suma += adc_leer(canal);
		_delay_ms(1);
	}
	return (uint16_t)(suma / N_MUESTRAS);
}

static void led_set(uint8_t verde, uint8_t amarillo, uint8_t rojo)
{
	uint8_t mascara = (1 << LED_GRN_PIN) | (1 << LED_YLW_PIN) | (1 << LED_RED_PIN);
	PORTD = (PORTD & ~mascara)
	| (verde    ? (1 << LED_GRN_PIN) : 0)
	| (amarillo ? (1 << LED_YLW_PIN) : 0)
	| (rojo     ? (1 << LED_RED_PIN) : 0);
}

static void buzzer_patron(uint16_t on_ms, uint16_t off_ms)
{
	cli();
	if (g_bz_on_ms != on_ms || g_bz_off_ms != off_ms)
	{
		g_bz_on_ms    = on_ms;
		g_bz_off_ms   = off_ms;
		g_bz_contador = 0;
		g_bz_fase     = 0;
	}
	sei();
}

static uint8_t boton_presionado(void)
{
	if (!(PINB & (1 << BTN_PIN)))
	{
		_delay_ms(20);
		if (!(PINB & (1 << BTN_PIN)))
		{
			while (!(PINB & (1 << BTN_PIN)));
			return 1;
		}
	}
	return 0;
}

int main(void)
{
	gpio_init();
	adc_init();
	timer0_init();
	timer1_init();
	uart_init();
	sei();

	led_set(1, 1, 1);
	_delay_ms(400);
	led_set(0, 0, 0);
	_delay_ms(200);

	uart_print("Monitor IR iniciado\n");

	while (1)
	{
		if (boton_presionado())
		{
			g_audio_habilitado ^= 1;
			if (g_audio_habilitado)
			uart_print("Audio ON\n");
			else
			uart_print("Audio OFF\n");
		}

		uint16_t valor_adc = adc_promedio(PHOTO_CH);
		char buffer[20];
		
		sprintf(buffer, "ADC:%d ", valor_adc);
		uart_print(buffer);

		if (valor_adc > 1022) 
		{
			uart_print("VERDE (lejos)\n");
			led_set(0, 0, 1);
			buzzer_patron(BZ_LENTO_ON, BZ_LENTO_OFF);
		}
		else if (valor_adc == 1021)
		{
			uart_print("ROJO (cerca)\n");
			led_set(0, 1, 0);
			buzzer_patron(BZ_RAPIDO_ON, BZ_RAPIDO_OFF);
		}
		else
		{
			uart_print("AMARILLO (medio)\n");
			led_set(1, 0, 0);
			buzzer_patron(BZ_MEDIO_ON, BZ_MEDIO_OFF);
		}

		_delay_ms(300);
	}
}