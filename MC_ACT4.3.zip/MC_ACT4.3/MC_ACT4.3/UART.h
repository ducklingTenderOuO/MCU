#ifndef UART_H_
#define UART_H_

#include <avr/io.h>

/* Baud rate � UBRR para F_CPU = 16MHz */
#define BAUD_9600     103
#define BAUD_19200     51
#define BAUD_38400     25
#define BAUD_115200     8

/* Data size � valor para bits UCSZ01:UCSZ00 */
#define DATA_5   0b00
#define DATA_6   0b01
#define DATA_7   0b10
#define DATA_8   0b11

/* Parity � valor para bits UPM01:UPM00 */
#define PARITY_NONE  0b00
#define PARITY_EVEN  0b10
#define PARITY_ODD   0b11

/* Stop bits � valor para bit USBS0 */
#define STOP_1  0
#define STOP_2  1

/* ?? Prototipos ?? */
void          UART_init(unsigned int baud, unsigned char data,
                        unsigned char parity, unsigned char stop);
unsigned char UART_read(void);
void          UART_write(unsigned char data);
void          UART_string(char* string);

void UART_init(unsigned int baud, unsigned char data,
               unsigned char parity, unsigned char stop)
{
    /* Baud rate */
    UBRR0 = baud;

    /* TX + RX habilitados + interrupci�n de recepci�n (RXCIE0)
     * Una sola l�nea � no sobreescribe bits anteriores          */
    UCSR0B = (1<<RXCIE0) | (1<<RXEN0) | (1<<TXEN0);

    UCSR0C = (parity << UPM00) | (stop << USBS0) | (data << UCSZ00);
}

/* Lee el byte recibido � llamar solo cuando RXC0 est� activo */
unsigned char UART_read(void)
{
    return UDR0;
}

/* Env�a un byte � espera hasta que el buffer est� libre */
void UART_write(unsigned char data)
{
    while(!(UCSR0A & (1<<UDRE0)));
    UDR0 = data;
}

/* Env�a una cadena terminada en null */
void UART_string(char* string)
{
    while(*string != 0)
    {
        UART_write(*string);
        string++;
    }
}

#endif /* UART_H_ */