#define F_CPU 16000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdbool.h>
#include "UART.h"
#include "EEPROM.h"

/* Direcci�n EEPROM para el estado de los 8 LEDs */
#define EEPROM_ADDR  0x00

/* Variables compartidas entre ISR y main */
volatile bool    RxFlag = false;
volatile uint8_t RxData = 0;

/* ?? Prototipos internos ?? */
void apply_leds(uint8_t state);
void print_state(uint8_t state);

void apply_leds(uint8_t state)
{
    /* PB0�PB5: bits 0�5 directo. M�scara 0xC0 protege PB6/PB7 (cristal) */
    PORTB = (PORTB & 0xC0) | (state & 0x3F);

    /* PC0 ? bit6 del estado | PC1 ? bit7 del estado
     * >>6 desplaza bit6?pos0 y bit7?pos1                */
    PORTC = (PORTC & 0xFC) | ((state >> 6) & 0x03);
}

void print_state(uint8_t state)
{
    for(int8_t i = 7; i >= 0; i--)
    {
        UART_write((state & (1<<i)) ? '1' : '0');
    }
    UART_string("\n\r");
}

int main(void)
{
    /* PB0�PB5 salidas | PB6�PB7 entradas (cristal) */
    DDRB = 0x3F;

    /* PC0 y PC1 como salidas para LED7 y LED8 */
    DDRC = (DDRC & 0xFC) | 0x03;

    /* UART: 9600 baud | 8 bits | sin paridad | 1 stop bit
     * Usa el nuevo UART_init() con par�metros              */
    UART_init(BAUD_9600, DATA_8, PARITY_NONE, STOP_1);

    /* ?? Parte 2: restaurar estado desde EEPROM ??
     * EEPROM virgen = 0xFF ? sin datos previos ? apagar todo */
    uint8_t led_state = EEPROM_read(EEPROM_ADDR);
    if(led_state == 0xFF) led_state = 0x00;
    apply_leds(led_state);

    sei(); /* Habilitar interrupciones globales */

    /* Mensaje de bienvenida */
    UART_string("=== Control 8 LEDs ===\n\r");
    UART_string("ON : 1 2 3 4 5 6 7 8\n\r");
    UART_string("OFF: Q W E R T Y U I\n\r");
    UART_string("Estado: ");
    print_state(led_state);

    /* ?? Bucle principal ?? */
    while(1)
    {
        if(RxFlag)
        {
            RxFlag = false;
            uint8_t cmd = RxData;

            /* ?? Encender: '1' a '8' ?? */
            if(cmd >= '1' && cmd <= '8')
            {
                uint8_t bit = cmd - '1';   /* '1'?0 ... '8'?7 */
                led_state |= (1 << bit);
                apply_leds(led_state);
                EEPROM_update(EEPROM_ADDR, led_state); /* Parte 2 */
                UART_string("LED");
                UART_write(cmd);
                UART_string(" ON  | ");
                print_state(led_state);
            }
            /* ?? Apagar: Q W E R T Y U I ?? */
            else
            {
                int8_t bit = -1;
                switch(cmd)
                {
                    case 'Q': case 'q':  bit = 0; break;
                    case 'W': case 'w':  bit = 1; break;
                    case 'E': case 'e':  bit = 2; break;
                    case 'R': case 'r':  bit = 3; break;
                    case 'T': case 't':  bit = 4; break;
                    case 'Y': case 'y':  bit = 5; break;
                    case 'U': case 'u':  bit = 6; break;
                    case 'I': case 'i':  bit = 7; break;
                    default:             bit = -1; break;
                }

                if(bit >= 0)
                {
                    led_state &= ~(1 << bit);
                    apply_leds(led_state);
                    EEPROM_update(EEPROM_ADDR, led_state); /* Parte 2 */
                    UART_string("LED");
                    UART_write('1' + bit);
                    UART_string(" OFF | ");
                    print_state(led_state);
                }
                else
                {
                    UART_string("INVALID\n\r");
                }
            }
        }
    }
}

ISR(USART_RX_vect)
{
    RxData = UDR0;   /* Leer aqu� � si no, se pierde el dato */
    RxFlag = true;
}