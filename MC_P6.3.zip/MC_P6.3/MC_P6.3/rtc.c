#include "rtc.h"

datetime_t current_time = {0,0,12,24,4,26};  // ? DEFINICI�N �nica aqu�

void rtc_init(void) {
	TCCR1B = (1<<CS12)|(1<<CS11)|(1<<CS10);
	TCNT1 = 34286;
	TIMSK1 |= (1<<TOIE1);
}

void rtc_adjust(uint8_t h, uint8_t m, uint8_t s) {
	current_time.hour = h;
	current_time.min = m;
	current_time.sec = s;
}

uint8_t is_access_allowed(uint8_t nivel) {
	uint8_t hour = current_time.hour;
	switch(nivel) {
		case 1: return 1;
		case 2: return (hour >= 6 && hour < 20);
		case 3: return (hour >= 9 && hour <= 12);
	}
	return 0;
}