#ifndef EEPROM_USERS_H
#define EEPROM_USERS_H

#include <avr/eeprom.h>

#define MAX_USERS 50
#define USER_SIZE 4  // ID (3 bytes BCD) + Nivel (1 byte)
#define EE_START 0x00

typedef struct {
	uint8_t id[3];     // ID 000-999 BCD
	uint8_t nivel;     // 1,2,3
} user_t;

uint8_t add_user(uint8_t* id_bcd, uint8_t nivel); // Alta usuario
uint8_t remove_user(uint8_t* id_bcd);             // Baja usuario
uint8_t find_user(uint8_t* id_bcd, user_t* user); // Busca usuario
void list_users(void);                            // Lista todos por UART
uint8_t user_count(void);                         // Nº usuarios

#endif