#include "uart.h"

void uart_init(void) {
	UBRR0H = (uint8_t)(UBRR_VAL >> 8);
	UBRR0L = (uint8_t)UBRR_VAL;
	UCSR0B = (1<<RXEN0)|(1<<TXEN0)|(1<<RXCIE0); // RX/TX + RX interrupt
	UCSR0C = (1<<UCSZ01)|(1<<UCSZ00); // 8 bits
}

void uart_tx_char(char c) {
	while (!(UCSR0A & (1<<UDRE0))); // Espera buffer vac�o
	UDR0 = c;
}

void uart_tx_string(const char* str) {
	while (*str) uart_tx_char(*str++);
	uart_tx_char('\r');
	uart_tx_char('\n');
}

char uart_rx_char(void) {
	while (!(UCSR0A & (1<<RXC0))); // Espera dato
	return UDR0;
}

uint8_t uart_rx_available(void) {
	return (UCSR0A & (1<<RXC0));
}