#include "keypad.h"

static const char keys[4][4] = {
	{'1','2','3','A'},
	{'4','5','6','B'},
	{'7','8','9','C'},
	{'*','0','#','D'}
};

char keypad_get_key(void) {
	uint8_t row, col;
	
	// Config filas salida alta (pull-up cols)
	KEYPAD_ROWS_DDR |= (1<<ROW0_PIN)|(1<<ROW1_PIN)|(1<<ROW2_PIN)|(1<<ROW3_PIN);
	KEYPAD_ROWS_PORT |= (1<<ROW0_PIN)|(1<<ROW1_PIN)|(1<<ROW2_PIN)|(1<<ROW3_PIN);
	
	// Leer columnas (PD4-PD7 entrada)
	DDRD &= ~((1<<PD4)|(1<<PD5)|(1<<PD6)|(1<<PD7));
	PORTD |= (1<<PD4)|(1<<PD5)|(1<<PD6)|(1<<PD7); // Pull-ups
	
	for (row = 0; row < 4; row++) {
		// Bajar fila activa a 0
		switch(row) {
			case 0: KEYPAD_ROWS_PORT &= ~(1<<ROW0_PIN); break;
			case 1: KEYPAD_ROWS_PORT &= ~(1<<ROW1_PIN); break;
			case 2: KEYPAD_ROWS_PORT &= ~(1<<ROW2_PIN); break;
			case 3: KEYPAD_ROWS_PORT &= ~(1<<ROW3_PIN); break;
		}
		_delay_ms(10); // Debounce
		
		// Leer cols
		col = 0;
		if (!(KEYPAD_COLS_PIN & (1<<PD4))) col = 0;
		else if (!(KEYPAD_COLS_PIN & (1<<PD5))) col = 1;
		else if (!(KEYPAD_COLS_PIN & (1<<PD6))) col = 2;
		else if (!(KEYPAD_COLS_PIN & (1<<PD7))) col = 3;
		
		// Subir fila
		switch(row) {
			case 0: KEYPAD_ROWS_PORT |= (1<<ROW0_PIN); break;
			case 1: KEYPAD_ROWS_PORT |= (1<<ROW1_PIN); break;
			case 2: KEYPAD_ROWS_PORT |= (1<<ROW2_PIN); break;
			case 3: KEYPAD_ROWS_PORT |= (1<<ROW3_PIN); break;
		}
		
		if (col != 4) return keys[row][col]; // Tecla encontrada
	}
	return '\0'; // Ninguna
}

uint8_t keypad_is_pressed(void) {
	return keypad_get_key() != '\0';
}