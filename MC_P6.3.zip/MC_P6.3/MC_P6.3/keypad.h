#ifndef KEYPAD_H
#define KEYPAD_H

#include <avr/io.h>
#include <util/delay.h>

#define KEYPAD_ROWS_DDR DDRB
#define KEYPAD_ROWS_PORT PORTB
#define KEYPAD_COLS_PIN PIND
#define ROW0_PIN PB3  // Fila 0: 1 2 3 A
#define ROW1_PIN PB2  // Fila 1: 4 5 6 B
#define ROW2_PIN PB1  // Fila 2: 7 8 9 C
#define ROW3_PIN PB0  // Fila 3: * 0 # D

char keypad_get_key(void);         // Lee tecla presionada o '\0'
uint8_t keypad_is_pressed(void);   // Verifica si hay tecla

#endif