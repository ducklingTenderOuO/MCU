#ifndef UART_H
#define UART_H

#ifndef F_CPU
#define F_CPU 16000000UL  // Fallback si no definido
#endif

#include <avr/io.h>

#define BAUD 9600
#define UBRR_VAL ((F_CPU/16/BAUD)-1)

void uart_init(void);              // UART 9600 8N1
void uart_tx_char(char c);         // Env�a car�cter
void uart_tx_string(const char* str); // Env�a cadena
char uart_rx_char(void);           // Recibe car�cter (bloqueante)
uint8_t uart_rx_available(void);   // Dato disponible?

#endif