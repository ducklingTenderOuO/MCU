#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include <string.h>
#include "lcd.h"
#include "keypad.h"
#include "uart.h"
#include "eeprom_users.h"
#include "rtc.h"

// ? QUITA estas funciones - van en rtc.c
// datetime_t current_time = {...};  ? BORRAR (extern en rtc.h)
// rtc_init(), rtc_adjust(), is_access_allowed() ? BORRAR

// ISR Timer1 - SOLO AQU�
ISR(TIMER1_OVF_vect) {
	extern datetime_t current_time;  // Referencia externa
	current_time.sec++;
	if (current_time.sec >= 60) {
		current_time.sec = 0;
		current_time.min++;
		if (current_time.min >= 60) {
			current_time.min = 0;
			current_time.hour++;
			if (current_time.hour >= 24) current_time.hour = 0;
		}
	}
}

// UART RX ISR
ISR(USART_RX_vect) {
	char c = UDR0;
	static char rx_buf[50];
	static uint8_t rx_idx = 0;
	
	if (c == '\r' || c == '\n') {
		rx_buf[rx_idx] = 0;
		// Parse: ADD:123:2 , DEL:123 , LIST , TIME:12:30:00
		if (strncmp(rx_buf, "ADD:", 4)==0) {
			uint8_t id[3] = {rx_buf[4]-'0', rx_buf[5]-'0', rx_buf[6]-'0'};
			uint8_t lvl = rx_buf[8]-'0';
			if (add_user(id, lvl)) uart_tx_string("OK: Agregado");
			} else if (strncmp(rx_buf, "DEL:", 4)==0) {
			uint8_t id[3] = {rx_buf[4]-'0', rx_buf[5]-'0', rx_buf[6]-'0'};
			remove_user(id);
			} else if (strcmp(rx_buf, "LIST")==0) {
			list_users();
			} else if (strncmp(rx_buf, "TIME:", 5)==0) {
			uint8_t h,m,s;
			sscanf(rx_buf+5, "%hhu:%hhu:%hhu", &h,&m,&s);
			rtc_adjust(h,m,s);
			uart_tx_string("OK: Hora ajustada");
		}
		rx_idx = 0;
		} else if (rx_idx < 49) {
		rx_buf[rx_idx++] = c;
	}
}

#define ENTER_KEY '#'
#define LED_GREEN PD2
#define LED_RED PD3

uint8_t input_id[3] = {0,0,0};
uint8_t id_pos = 0;
uint8_t access_mode = 1; // 1=acceso, 0=admin

int main(void) {
	// Pines LEDs
	DDRD |= (1<<LED_GREEN)|(1<<LED_RED);
	
	// Teclado cols pull-up
	DDRD &= ~((1<<PD4)|(1<<PD5)|(1<<PD6)|(1<<PD7));
	PORTD |= (1<<PD4)|(1<<PD5)|(1<<PD6)|(1<<PD7);
	
	uart_init();
	lcd_init();
	rtc_init();
	
	char buf[21];  // LCD 20 chars max
	
	uart_tx_string("Terminal v1.0 INICIADO");
	uart_tx_string("ADD:123:2 DEL:123 LIST TIME:14:30:00");
	
	sei();  // Interrupciones globales
	
	while(1) {
		// L�nea 0: Fecha/Hora
		sprintf(buf, "%02d/%02d/26 %02d:%02d:%02d",
		current_time.day, current_time.month,
		current_time.hour, current_time.min, current_time.sec);
		lcd_set_cursor(0,0);
		lcd_write_string(buf);
		
		if (access_mode) {
			// ID entrada
			sprintf(buf, "ID:%u%u%u  #=Enter A=Admin",
			input_id[0], input_id[1], input_id[2]);
			lcd_set_cursor(1,0);
			lcd_write_string(buf);
			
			char key = keypad_get_key();
			if (key >= '0' && key <= '9' && id_pos < 3) {
				input_id[id_pos++] = key - '0';
				_delay_ms(150);
				} else if (key == ENTER_KEY && id_pos == 3) {
				// Validar
				user_t user;
				sprintf(buf, "Validando %u%u%u...", input_id[0],input_id[1],input_id[2]);
				lcd_clear();
				lcd_write_string(buf);
				
				if (find_user(input_id, &user)) {
					uint8_t ok = is_access_allowed(user.nivel);
					sprintf(buf, "ID:%u%u%u %s N%d", input_id[0],input_id[1],input_id[2],
					ok?"ACCESO":"RECHAZO", user.nivel);
					lcd_clear();
					lcd_write_string(buf);
					
					// LED + LOG
					if (ok) {
						PORTD |= (1<<LED_GREEN); _delay_ms(2000); PORTD &= ~(1<<LED_GREEN);
						sprintf(buf,"LOG:ACC %02d:%02d:%02d %u%u%u N%d",
						current_time.hour,current_time.min,current_time.sec,
						input_id[0],input_id[1],input_id[2], user.nivel);
						} else {
						PORTD |= (1<<LED_RED); _delay_ms(2000); PORTD &= ~(1<<LED_RED);
						sprintf(buf,"LOG:REJ %02d:%02d:%02d %u%u%u RST",
						current_time.hour,current_time.min,current_time.sec,
						input_id[0],input_id[1],input_id[2]);
					}
					uart_tx_string(buf);
					} else {
					lcd_clear();
					lcd_write_string("RECHAZO: ID desconocido");
					PORTD |= (1<<LED_RED); _delay_ms(2000); PORTD &= ~(1<<LED_RED);
					sprintf(buf,"LOG:REJ %02d:%02d:%02d %u%u%u DEN",
					current_time.hour,current_time.min,current_time.sec,
					input_id[0],input_id[1],input_id[2]);
					uart_tx_string(buf);
				}
				// Reset
				id_pos = 0;
				memset(input_id, 0, 3);
				_delay_ms(2000);
				} else if (key == 'A') {
				access_mode = 0;
				lcd_clear();
				lcd_write_string("ADMIN UART - A=acceso");
			}
			} else {
			lcd_set_cursor(1,0);
			lcd_write_string("ADMIN UART espera...");
			char key = keypad_get_key();
			if (key == 'A') {
				access_mode = 1;
				lcd_clear();
			}
		}
		_delay_ms(50);
	}
}