#ifndef RTC_H
#define RTC_H

#include <avr/io.h>

typedef struct {
	uint8_t sec, min, hour, day, month, year;
} datetime_t;

extern datetime_t current_time;    // ? EXTERN solo aqu�
extern void rtc_init(void);
extern void rtc_adjust(uint8_t h, uint8_t m, uint8_t s);
extern uint8_t is_access_allowed(uint8_t nivel);

#endif