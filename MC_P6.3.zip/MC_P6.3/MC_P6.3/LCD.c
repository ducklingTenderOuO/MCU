#ifndef LCD_H
#define LCD_H

#include <avr/io.h>
#include <util/delay.h>

// Pines LCD en PORTC
#define LCD_RS_PORT PORTC
#define LCD_RS_DDR DDRC
#define LCD_RS_PIN PC0

#define LCD_EN_PORT PORTC
#define LCD_EN_DDR DDRC
#define LCD_EN_PIN PC1

#define LCD_D4_PORT PORTC
#define LCD_D4_DDR DDRC
#define LCD_D4_PIN PC2
#define LCD_D5_PIN PC3
#define LCD_D6_PIN PC4
#define LCD_D7_PIN PC5

// Prototipos
void lcd_init(void);           // Inicializa LCD en 4 bits
void lcd_clear(void);          // Borra pantalla
void lcd_home(void);           // Posición inicial
void lcd_set_cursor(uint8_t row, uint8_t col); // Cursor fila,col
void lcd_write_char(char c);   // Escribe carácter
void lcd_write_string(const char* str); // Escribe cadena
void lcd_write_nibble(uint8_t nibble); // Escribe nibble (4 bits)

#endif