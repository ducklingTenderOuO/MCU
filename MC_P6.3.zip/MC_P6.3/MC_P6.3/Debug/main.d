main.d main.o: .././main.c d:\microchip\avr\avr\include\avr\io.h \
 d:\microchip\avr\avr\include\avr\sfr_defs.h \
 d:\microchip\avr\avr\include\inttypes.h \
 d:\microchip\avr\avr\include\features.h \
 d:\microchip\avr\lib\gcc\avr\5.4.0\include\stdint.h \
 d:\microchip\avr\avr\include\stdint.h \
 d:\microchip\avr\avr\include\bits\alltypes.h \
 d:\microchip\avr\avr\include\bits\stdint.h \
 D:/Microchip/7.0/Packs/atmel/ATmega_DFP/1.7.374/xc8/avr/include/avr/iom328p.h \
 d:\microchip\avr\avr\include\avr\portpins.h \
 d:\microchip\avr\avr\include\avr\common.h \
 d:\microchip\avr\avr\include\avr\fuse.h \
 d:\microchip\avr\avr\include\avr\lock.h \
 d:\microchip\avr\avr\include\avr\interrupt.h \
 d:\microchip\avr\avr\include\util\delay.h \
 d:\microchip\avr\avr\include\util\delay_basic.h \
 d:\microchip\avr\avr\include\math.h d:\microchip\avr\avr\include\stdio.h \
 d:\microchip\avr\avr\include\string.h .././lcd.h .././keypad.h \
 .././uart.h .././eeprom_users.h \
 d:\microchip\avr\avr\include\avr\eeprom.h \
 d:\microchip\avr\lib\gcc\avr\5.4.0\include\stddef.h .././rtc.h

d:\microchip\avr\avr\include\avr\io.h:

d:\microchip\avr\avr\include\avr\sfr_defs.h:

d:\microchip\avr\avr\include\inttypes.h:

d:\microchip\avr\avr\include\features.h:

d:\microchip\avr\lib\gcc\avr\5.4.0\include\stdint.h:

d:\microchip\avr\avr\include\stdint.h:

d:\microchip\avr\avr\include\bits\alltypes.h:

d:\microchip\avr\avr\include\bits\stdint.h:

D:/Microchip/7.0/Packs/atmel/ATmega_DFP/1.7.374/xc8/avr/include/avr/iom328p.h:

d:\microchip\avr\avr\include\avr\portpins.h:

d:\microchip\avr\avr\include\avr\common.h:

d:\microchip\avr\avr\include\avr\fuse.h:

d:\microchip\avr\avr\include\avr\lock.h:

d:\microchip\avr\avr\include\avr\interrupt.h:

d:\microchip\avr\avr\include\util\delay.h:

d:\microchip\avr\avr\include\util\delay_basic.h:

d:\microchip\avr\avr\include\math.h:

d:\microchip\avr\avr\include\stdio.h:

d:\microchip\avr\avr\include\string.h:

.././lcd.h:

.././keypad.h:

.././uart.h:

.././eeprom_users.h:

d:\microchip\avr\avr\include\avr\eeprom.h:

d:\microchip\avr\lib\gcc\avr\5.4.0\include\stddef.h:

.././rtc.h:
