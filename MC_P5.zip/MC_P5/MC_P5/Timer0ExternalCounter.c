/*
 * Timer0ExternalCounter.c
 *
 * Created: 12/03/2026 01:29:23 a. m.
 *  Author: astri
 */ 

#include <avr/io.h>

int main(void)
{
	// I/Os Config.
	DDRB |= 0xFF; // PORTB as Outputs
	DDRD &= ~(1<<PIND4); // PIND4 as Input (T0)
	PORTD |= 1<<PIND4; // PIND4 Pull-up Enable

	// Timer0 Config.
	TCNT0 = 0; // Initialize counter value
	// ClockSelect=110:Ext.Source(T0)-FallingEdge
	TCCR0B |= (1<<CS02)|(1<<CS01)|(0<<CS00);

	while (1)
	{
		// Output the counter value
		PORTB = TCNT0;
	}
}