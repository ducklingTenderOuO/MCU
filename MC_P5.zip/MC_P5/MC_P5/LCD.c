#include <avr/io.h>
#include "LCD.h"
 
static void write_nibble(uint8_t nibble_shifted)
{
    /* Preservar RS y EN (bits 0 y 1), escribir datos en bits 5-2 */
    DATA_BUS = (DATA_BUS & 0x03) | (nibble_shifted & 0x3C);
}
 
/* Pulso de Enable: minimo 450 ns HIGH, 500 ns LOW segun datasheet     */
static void pulse_en(void)
{
    CTL_BUS |=  (1 << LCD_EN);
    _delay_us(1);
    CTL_BUS &= ~(1 << LCD_EN);
    _delay_us(50);   /* tiempo de ejecucion del comando en el HD44780  */
}
 
/*  Enviar un byte completo (comando o dato) en 2 nibbles              */
static void send_byte(uint8_t byte, uint8_t rs)
{
    /* Configurar RS: 0=comando, 1=dato */
    if (rs)
        CTL_BUS |=  (1 << LCD_RS);
    else
        CTL_BUS &= ~(1 << LCD_RS);
 
    /* Nibble alto: bits 7-4 del byte -> desplazar >>2 para PC5-PC2   */
    write_nibble((byte & 0xF0) >> 2);
    pulse_en();
 
    /* Nibble bajo: bits 3-0 del byte -> desplazar <<2 para PC5-PC2   */
    write_nibble((byte << 2) & 0x3C);
    pulse_en();
}
 
void lcd_send_command(uint8_t command)
{
    send_byte(command, 0);
    _delay_ms(2);
}
 
void lcd_write_character(uint8_t character)
{
    send_byte(character, 1);
}
 
void lcd_init(void)
{
    /* Configurar PORTC como salida completo */
    DATA_DDR |= (1<<LCD_D7)|(1<<LCD_D6)|(1<<LCD_D5)|(1<<LCD_D4)
               |(1<<LCD_EN)|(1<<LCD_RS);
 
    /* Asegurar EN=0, RS=0 y datos=0 al inicio */
    CTL_BUS  &= ~((1<<LCD_EN)|(1<<LCD_RS));
    DATA_BUS &= ~((1<<LCD_D7)|(1<<LCD_D6)|(1<<LCD_D5)|(1<<LCD_D4));
 
    _delay_ms(50);   /* Esperar >40 ms tras Vcc > 2.7 V               */
 
    /* Pulso 1 */
    CTL_BUS  &= ~(1<<LCD_RS);
    write_nibble(0x30 >> 2);   /* 0x0C en PORTC bits 5-2 -> 0b001100 */
    pulse_en();
    _delay_ms(5);
 
    /* Pulso 2 */
    write_nibble(0x30 >> 2);
    pulse_en();
    _delay_ms(1);
 
    /* Pulso 3 */
    write_nibble(0x30 >> 2);
    pulse_en();
    _delay_us(150);
 
    write_nibble(0x20 >> 2);   /* 0x08 en bits 5-2 -> solo PC3=1      */
    pulse_en();
    _delay_us(150);
 
    lcd_send_command(LCD_CMD_4BIT_2ROW_5X7);
 
    /* Display OFF */
    lcd_send_command(0x08);
 
    /* Clear display */
    lcd_send_command(LCD_CMD_CLEAR_DISPLAY);
    _delay_ms(2);
 
    /* Entry mode: incremento automatico, sin shift */
    lcd_send_command(0x06);
 
    /* Display ON, cursor OFF, blink OFF */
    lcd_send_command(LCD_CMD_DISPLAY_NO_CURSOR);
}
 
void lcd_write_word(uint8_t word[])
{
    int i = 0;
    while (word[i] != '\0')
    {
        lcd_write_character(word[i]);
        i++;
    }
}
 
void lcd_clear(void)
{
    lcd_send_command(LCD_CMD_CLEAR_DISPLAY);
    _delay_ms(2);
}
 
void lcd_goto_xy(uint8_t row, uint8_t col)
{
    uint8_t address = (row == 0) ? (0x00 + col) : (0x40 + col);
    lcd_send_command(0x80 | address);
}
 
void lcd_print(char *str)
{
    while (*str)
        lcd_write_character((uint8_t)(*str++));
}
 
void lcd_print_int(long num)
{
    char buffer[12];
    uint8_t i = 0;
 
    if (num == 0) { lcd_write_character('0'); return; }
 
    if (num < 0)
    {
        lcd_write_character('-');
        num = -num;
    }
 
    while (num > 0 && i < 11)
    {
        buffer[i++] = '0' + (uint8_t)(num % 10);
        num /= 10;
    }
 
    while (i > 0)
        lcd_write_character((uint8_t)buffer[--i]);
}