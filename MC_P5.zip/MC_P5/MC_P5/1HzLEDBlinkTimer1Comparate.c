/*
 * _1HzLEDBlinkTimer1Comparate.c
 *
 * Created: 12/03/2026 01:31:37 a. m.
 *  Author: astri
 */ 

#include <avr/io.h>

int main(void)
{
	// DDRB Config.
	DDRB |= 1<<PINB1; // 'PinB1' as Output

	// Timer1 Config.
	// ClockSelect=101: Prescaler 1024
	TCCR1B |= (1<<CS12)|(0<<CS11)|(1<<CS10);
	// Clear Timer on Compare Match (CTC)
	TCCR1B |= (1<<WGM12);

	// Output A Mode = Toggle on Match
	TCCR1A |= (0<<COM1A1)|(1<<COM1A0);
	// Compare value = 1Hz Blink
	OCR1A = 7812; //500ms toggle

	while (1)
	{
	}
}
