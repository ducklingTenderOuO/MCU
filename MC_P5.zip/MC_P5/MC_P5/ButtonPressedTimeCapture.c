/*
 * ButtonPressedTimeCapture.c
 *
 * Created: 12/03/2026 01:33:36 a. m.
 *  Author: astri
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include "LCD.h"

char int_str[10];
uint8_t flag = 0;
uint16_t cvalue = 0;
float tvalue = 0;

int main(void)
{
	// GPIOs Config.
	DDRD |= 1<<PIND7;   // Configure PinD7 as Output
	DDRB &= ~(1<<PINB0); // Configure Input Capture Pin as Input
	PORTB |= (1<<PINB0); // Configure Input Capture Pin Pull-up

	// Timer1 Config.
	// Noise Canceler: Enabled/Capture Edge:Rising/Prescaler:1024
	TCCR1B |= (1<<ICNC1)|(1<<ICES1)|(1<<CS12)|(0<<CS11)|(1<<CS10);
	TIMSK1 |= (1<<ICF1);   // Clear Interrupt Flag ICF1
	TIMSK1 |= (1<<ICIE1);  // Enable Input Capture Interrupt
	sei();    // Enable Global Interrupt
	// LCD Init.
	lcd_init();
	
	while (1)
	{
		if ((!(PINB & (1<<PINB0))) && (flag==0))
		{
			TCNT1 = 0; // Clear Counter Register
			flag = 1; // Set button pressed flag
		}
		else if (flag == 2)
		{
			flag = 0; // Clear Button Pressed Flag
			cvalue = ICR1;
			lcd_clear();
			// Print Capture Register Value
			sprintf(int_str, "%6u Cycles", cvalue);
			lcd_goto_xy(0,0);
			lcd_write_word(int_str);
			// Print Pressed Time Value
			// (1/(Fclk/Prescaler)) * ICR1 * 1000 [ms]
			tvalue = ((cvalue*1000.0)/(15625.0));
			sprintf(int_str, "%6.2f ms", tvalue);
			lcd_goto_xy(1,0);
			lcd_write_word(int_str);
		}
	}
}

ISR(TIMER1_CAPT_vect)
{
	if (flag == 1)
	{
		flag = 2; // Change Button Pressed Flag
		PORTD ^= (1 << PIND7); // Toggle PinD7
	}
}