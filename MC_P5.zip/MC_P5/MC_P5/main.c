/*
 * MC_P5.c
 *
 * Created: 12/03/2026 01:26:24 a. m.
 * Author : astri
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>
#include "LCD.h"

#define LCD_ROW_FIRST  1
 
#if LCD_ROW_FIRST
  #define LCD_POS(row, col)  lcd_goto_xy((row), (col))
#else
  #define LCD_POS(row, col)  lcd_goto_xy((col), (row))
#endif
 
#define TRIG_PIN        PD4
#define ECHO_PIN        PB0   /* ICP1 - no modificable */
#define BTN_UNITS       PD2
#define BTN_COLLISION   PD3
#define BUZZER_PIN      PD5

#define TICKS_PER_CM    116.0f

#define OCR1A_VALUE     19999
#define INTS_PER_SECOND 100
 
#define DIST_MIN_CM     2
#define DIST_MAX_CM     50
#define COLLISION_CM    10
#define LCD_COLS        16
 
volatile uint16_t g_rise_tick  = 0;   /* Tick del flanco de subida    */
volatile uint16_t g_fall_tick  = 0;   /* Tick del flanco de bajada    */
volatile uint8_t  g_echo_ready = 0;   /* 1 = medicion lista           */
volatile uint8_t  g_trigger_now = 0;  /* 1 = disparar siguiente Trig  */
volatile uint8_t  g_int_count  = 0;   /* Contador de interrupciones   */
 
/* Estado de la aplicacion */
volatile uint8_t  g_units_m    = 0;   
volatile uint8_t  g_collision  = 0;   
 
static void gpio_init(void);
static void timer1_init(void);
static void trigger_pulse(void);
static void display_distance(float dist_cm);
static void display_collision_bar(float dist_cm);
static void buzzer_control(float dist_cm);
static float compute_distance(void);
 
int main(void)
{
    gpio_init();
    timer1_init();
    lcd_init();
    sei();
 
    /* Mensaje de bienvenida */
    lcd_clear();
    LCD_POS(0, 0);
    lcd_write_word((uint8_t *)"Dist. Meter");
    LCD_POS(1, 0);
    lcd_write_word((uint8_t *)"HC-SR04 Ready");
    _delay_ms(1500);
    lcd_clear();
 
    /* Primer disparo inmediato */
    trigger_pulse();
 
    while (1)
    {
        /* --- Procesar medicion cuando el eco esta listo --- */
        if (g_echo_ready)
        {
            g_echo_ready = 0;
            float dist_cm = compute_distance();
 
            display_distance(dist_cm);
 
            if (g_collision)
            {
                display_collision_bar(dist_cm);
                buzzer_control(dist_cm);
            }
            else
            {
                /* Limpiar fila 2 y buzzer si se desactivo modo colision */
                LCD_POS(1, 0);
                lcd_write_word((uint8_t *)"                ");
                PORTD &= ~(1 << BUZZER_PIN);
            }
        }
 
        /* --- Disparar nuevo Trigger cada 1 segundo --- */
        if (g_trigger_now)
        {
            g_trigger_now = 0;
            trigger_pulse();
        }
    }
}
 
static void gpio_init(void)
{
    /* Trigger: salida */
    DDRD  |=  (1 << TRIG_PIN);
    PORTD &= ~(1 << TRIG_PIN);   /* Inactivo en LOW */
 
    /* Echo (ICP1): entrada sin pull-up (el HC-SR04 maneja el nivel) */
    DDRB  &= ~(1 << ECHO_PIN);
    PORTB &= ~(1 << ECHO_PIN);
 
    /* Botones: entrada con pull-up interno */
    DDRD  &= ~((1 << BTN_UNITS) | (1 << BTN_COLLISION));
    PORTD |=   (1 << BTN_UNITS) | (1 << BTN_COLLISION);
 
    /* Buzzer: salida, inactivo */
    DDRD  |=  (1 << BUZZER_PIN);
    PORTD &= ~(1 << BUZZER_PIN);
 
    /* Habilitar interrupciones externas para botones */
    /* INT0 (PD2) y INT1 (PD3): flanco de bajada */
    EICRA |= (1 << ISC01) | (0 << ISC00);   /* INT0: falling edge */
    EICRA |= (1 << ISC11) | (0 << ISC10);   /* INT1: falling edge */
    EIMSK |= (1 << INT0)  | (1 << INT1);
}
 
/*  Inicializacion de Timer1                                            */
static void timer1_init(void)
{
    TCCR1A = 0;
    TCCR1B = 0;
 
    /* WGM12: CTC mode */
    TCCR1B |= (1 << WGM12);
 
    /* Prescaler 8: CS11 */
    TCCR1B |= (1 << CS11);
 
    /* Cancelador de ruido: ICNC1
       Flanco inicial: SUBIDA (ICES1=1) para capturar inicio del Echo */
    TCCR1B |= (1 << ICNC1) | (1 << ICES1);
 
    /* Valor de comparacion: interrupcion cada 10ms (100 Hz) */
    OCR1A = OCR1A_VALUE;
 
    /* Habilitar interrupcion por Input Capture y por Compare Match A */
    TIMSK1 |= (1 << ICIE1) | (1 << OCIE1A);
 
    TCNT1 = 0;
}
 
static void trigger_pulse(void)
{
    g_echo_ready = 0;
    g_rise_tick  = 0;
    g_fall_tick  = 0;
 
    /* Limpiar bandera de captura antes de enviar pulso */
    TIFR1 |= (1 << ICF1);
 
    /* Configurar para capturar flanco de SUBIDA primero */
    TCCR1B |= (1 << ICES1);
 
    /* Pulso Trigger: HIGH 10 us */
    PORTD |=  (1 << TRIG_PIN);
    _delay_us(12);
    PORTD &= ~(1 << TRIG_PIN);
}
 
/*  Calculo de distancia en cm                                          */
static float compute_distance(void)
{
    uint16_t elapsed;
 
    /* Manejo de desbordamiento del contador entre flancos */
    if (g_fall_tick >= g_rise_tick)
        elapsed = g_fall_tick - g_rise_tick;
    else
        elapsed = (0xFFFF - g_rise_tick) + g_fall_tick + 1;
 
    float dist_cm = (float)elapsed / TICKS_PER_CM;
 
    /* Limitar al rango valido del sensor */
    if (dist_cm < DIST_MIN_CM) dist_cm = DIST_MIN_CM;
    if (dist_cm > DIST_MAX_CM) dist_cm = DIST_MAX_CM;
 
    return dist_cm;
}
 
static void display_distance(float dist_cm)
{
    uint8_t buf[17];
    uint16_t ent, dec;
 
    LCD_POS(0, 0);
 
    if (g_units_m)
    {
        /* Convertir cm a mm enteros, luego extraer m y cm como decimales */
        uint16_t cm_int = (uint16_t)dist_cm;           
        ent = cm_int / 100;                            
        dec = cm_int % 100;                            
        sprintf((char *)buf, "Dist:   %u.%02u m ", ent, dec);
    }
    else
    {
        /* Distancia en cm con un decimal: multiplicar x10 para tener dec */
        uint16_t cm_x10 = (uint16_t)(dist_cm * 10.0f + 0.5f); /* redondeo */
        ent = cm_x10 / 10;
        dec = cm_x10 % 10;
        sprintf((char *)buf, "Dist: %3u.%u cm  ", ent, dec);
    }
 
    lcd_write_word(buf);
}
 
/*  Barra de proximidad en la fila 2 (modo colision)                   */
static void display_collision_bar(float dist_cm)
{
    uint8_t buf[17];
    uint8_t filled;
    uint8_t i;
 
    filled = (uint8_t)(((float)(DIST_MAX_CM - dist_cm) /
                         (float)(DIST_MAX_CM - DIST_MIN_CM)) * LCD_COLS);
 
    if (filled > LCD_COLS) filled = LCD_COLS;
 
    for (i = 0; i < LCD_COLS; i++)
        buf[i] = (i < filled) ? 0xFF : ' ';   /* 0xFF = bloque solido en LCD */
    buf[LCD_COLS] = '\0';
 
    LCD_POS(1, 0);
    lcd_write_word(buf);
}
 
/*  Control de buzzeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeer*/
static void buzzer_control(float dist_cm)
{
    if (dist_cm < COLLISION_CM)
        PORTD |=  (1 << BUZZER_PIN);   /* Encender buzzer activo */
    else
        PORTD &= ~(1 << BUZZER_PIN);   /* Apagar buzzer          */
}
 
/*  ISR: Timer1 Input Capture                                           */
ISR(TIMER1_CAPT_vect)
{
    if (TCCR1B & (1 << ICES1))
    {
        /* Flanco de SUBIDA capturado: inicio del pulso Echo */
        g_rise_tick = ICR1;
        /* Cambiar a captura de flanco de BAJADA */
        TCCR1B &= ~(1 << ICES1);
    }
    else
    {
        /* Flanco de BAJADA capturado: fin del pulso Echo */
        g_fall_tick  = ICR1;
        g_echo_ready = 1;
        /* Restaurar a flanco de SUBIDA para el proximo ciclo */
        TCCR1B |= (1 << ICES1);
    }
}
 
/*  ISR: Timer1 Compare Match A - disparo cada 1 segundo               */
ISR(TIMER1_COMPA_vect)
{
    g_int_count++;
    if (g_int_count >= INTS_PER_SECOND)
    {
        g_int_count   = 0;
        g_trigger_now = 1;   /* Senal al main loop para el siguiente Trigger */
    }
}
 
/*  ISR: INT0 - Boton de unidades (PD2)                                */
ISR(INT0_vect)
{
    _delay_ms(30);   /* Debounce */
    if (!(PIND & (1 << BTN_UNITS)))
    {
        g_units_m ^= 1;   /* Alternar cm / m */
    }
}
 
/*  ISR: INT1 - Boton de modo colision (PD3)                           */
ISR(INT1_vect)
{
    _delay_ms(30);   /* Debounce */
    if (!(PIND & (1 << BTN_COLLISION)))
    {
        g_collision ^= 1;   /* Activar / desactivar modo colision */
 
        if (!g_collision)
        {
            /* Al desactivar: limpiar fila 2 y apagar buzzer de inmediato */
            PORTD &= ~(1 << BUZZER_PIN);
            LCD_POS(1, 0);
            lcd_write_word((uint8_t *)"                ");
        }
    }
}
 