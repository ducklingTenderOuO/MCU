/*
 * _1s8_bitCounterTimer1.c
 *
 * Created: 12/03/2026 01:32:41 a. m.
 *  Author: astri
 */ 

#include <avr/io.h>

int main(void)
{
	// I/Os Config.
	DDRD |= 0xFF; // PORTD as Outputs
	PORTB = 0; // Initialize port value
	// Timer1 Config.
	TCNT1 = 0; // Initialize counter value
	// ClockSelect = 100: Prescaler 256
	TCCR1B |= (1<<CS12)|(0<<CS11)|(0<<CS10);
	// Clear Timer on Compare Match (CTC)
	TCCR1B |= (1<<WGM12);
	// Compare Value = 1 second delay
	OCR1A = 62500;
	// Enable Output Compare A Match Int.
	TIMSK1 = (1<<OCIE1A);
	// Enable Global Interrupt
	sei();
	while (1);
}

ISR(TIMER1_COMPA_vect)
{
	PORTD++;
}