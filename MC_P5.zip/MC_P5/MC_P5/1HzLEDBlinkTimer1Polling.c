/*
 * _1HzLEDBlinkTimer1.c
 *
 * Created: 12/03/2026 01:30:20 a. m.
 *  Author: astri
 */ 

#include <avr/io.h>

int main(void)
{
	// DDRB Config.
	DDRB |= 0xFF; // PORTB as Outputs

	// Timer1 Config.
	TCNT1 = 0; // Initialize counter value
	// ClockSelect=101: Prescaler 1024
	TCCR1B |= (1<<CS12)|(0<<CS11)|(1<<CS10);
	// 1Hz Blink Value
	int cValue = 7812; //500ms toggle

	while (1)
	{
		if (TCNT1 == cValue)
		{
			PORTB ^= 0xFF; // Toggle PORTB
			TCNT1 = 0; // Restart counter
		}
	}
}