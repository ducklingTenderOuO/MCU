.def    mask    = r16    ; mask register
.def    ledR    = r17    ; led register
.def    oLoopR  = r18    ; outer loop register
.def    iLoopR1 = r24    ; inner loop register low
.def    iLoopRh = r25    ; inner loop register high

.equ    oVal    = 75    ; outer loop value (calculado)
.equ    iVal    = 63999  ; inner loop value (calculado)

.cseg
.org    0x00

    clr ledR              ; clear led register
    ldi mask,(1<<PINB5)   ; load 00100000 into mask register PIN13
    out DDRB,mask         ; set PINB5 as output

start:
    eor ledR,mask         ; toggle PINB5 in led register (1 cycle)
    out PORTB,ledR        ; write led register to PORTB (1 cycle)
    ldi oLoopR,oVal       ; initialize outer loop count (1 cycle)

oLoop:
    ldi iLoopR1,LOW(iVal)  ; initialize inner loop count (1 cycle)
    ldi iLoopRh,HIGH(iVal) ; loop high and low registers (1 cycle)

iLoop:
    sbiw    iLoopR1,1      ; decrement iLoop registers (2 cycles)
    brne    iLoop          ; branch to iLoop if iLoopR1!=0 (1 or 2 cycles)

    dec     oLoopR         ; decrement oLoopR (1 cycle)
    brne    oLoop          ; branch to oLoop if oLoopR!=0 (1 or 2 cycles)
    rjmp    start          ; jump back to start (2 cycles)